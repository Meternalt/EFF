﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace FileTools
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            AddSection("Level 1. Beginner");
            AddButton("Task 1. Calculator",
                () => new Level1.Task1_Calculator.CalculatorForm());

            AddButton("Task 2. Analyzer",
               () => new Level1.Task2_Analyzer.AnalyzerForm());

            AddButton("Task 3. Tree JSON",
                () => new Level1.Task3_Tree.TreeNavigatorForm());

            //AddSection("Level 2. Mid");
            //AddButton("Task 4. Downloader"),
            //    () => new Level2.Task4_Downloader.DownloaderForm());
            //AddButton("Task 5. Treker"),
            //    () => new Level2.Task5_Tasks.TasksForm());
            //AddButton("Task 6. DataGriew"),
            //    () => new Level2.Task6_VirtualGrid.VirtualGridForm());
        }

        private void AddSection(string title)
        {
            menuPanel.Controls.Add(new Label
            {
                Text = title,
                AutoSize = true,
                Margin = new Padding(0, 12, 0, 4),
            });
        }

        private void AddButton(string caption, Func<Form> factory)
        {
            var btn = new Button
            {
                Text = caption,
                Width = 340,
                Height = 42,
                TextAlign = ContentAlignment.MiddleLeft,
                Padding = new Padding(12, 0, 0, 0),
                FlatStyle = FlatStyle.System,
                Margin = new Padding(0, 4, 0, 4)
            };

            btn.Click += (s, e) =>
            {
                var form = factory();
                form.StartPosition = FormStartPosition.CenterParent;
                form.ShowDialog(this);
            };

            menuPanel.Controls.Add(btn);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }
    }
}
