﻿using System;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileTools.Level1.Task2_Analyzer
{
    public partial class AnalyzerForm : Form
    {
        private CancellationTokenSource _cts;
        private readonly IProgress<TextStatistics> _progress;

        public AnalyzerForm()
        {
            InitializeComponent();

            // Progress<T> сам маршалит вызов в UI-поток — можно смело Report() из фона.
            _progress = new Progress<TextStatistics>(Render);

            // Debounce: пока пользователь печатает, перезапускаем таймер.
            rtbText.TextChanged += (s, e) =>
            {
                debounceTimer.Stop();
                debounceTimer.Start();
            };

            // Таймер сработал — пользователь перестал печатать 300 мс.
            debounceTimer.Tick += async (s, e) =>
            {
                debounceTimer.Stop();
                await AnalyzeAsync();
            };

            // Первичная отрисовка пустого состояния
            Render(new TextStatistics());
        }

        private async Task AnalyzeAsync()
        {
            // Отменяем предыдущий расчёт, если он ещё идёт
            if (_cts != null)
            {
                _cts.Cancel();
                _cts.Dispose();
            }
            _cts = new CancellationTokenSource();
            var token = _cts.Token;

            // Снимаем копию текста — RichTextBox нельзя читать из фонового потока
            string text = rtbText.Text;

            try
            {
                var stats = await Task.Run(() => TextStatistics.Compute(text, token), token);

                if (token.IsCancellationRequested) return;
                _progress.Report(stats);
            }
            catch (OperationCanceledException)
            {
                // Ничего — просто отменено
            }
            catch (Exception ex)
            {
                // Сюда попадаем при непредвиденной ошибке
                MessageBox.Show(this,
                    "Ошибка анализа: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void Render(TextStatistics stats)
        {
            lblWords.Text = "Слов: " + stats.WordCount.ToString("N0");
            lblUnique.Text = "Уникальных: " + stats.UniqueWords.ToString("N0");
            lblReading.Text = "Время чтения: " + stats.ReadingMinutes.ToString("0.0") + " мин";

            if (stats.Top5.Count == 0)
            {
                lblTop.Text = "Топ-5: —";
            }
            else
            {
                var parts = new System.Collections.Generic.List<string>();
                foreach (var kv in stats.Top5)
                    parts.Add(kv.Key + "(" + kv.Value + ")");
                lblTop.Text = "Топ-5: " + string.Join(", ", parts);
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_cts != null)
            {
                _cts.Cancel();
                _cts.Dispose();
                _cts = null;
            }
            base.OnFormClosing(e);
        }
    }
}