﻿namespace FileTools.Level1.Task2_Analyzer
{
    partial class AnalyzerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.root = new System.Windows.Forms.TableLayoutPanel();
            this.rtbText = new System.Windows.Forms.RichTextBox();
            this.statsPanel = new System.Windows.Forms.Panel();
            this.statsGrid = new System.Windows.Forms.TableLayoutPanel();
            this.lblWords = new System.Windows.Forms.Label();
            this.lblTop = new System.Windows.Forms.Label();
            this.lblUnique = new System.Windows.Forms.Label();
            this.lblReading = new System.Windows.Forms.Label();
            this.debounceTimer = new System.Windows.Forms.Timer(this.components);
            this.root.SuspendLayout();
            this.statsPanel.SuspendLayout();
            this.statsGrid.SuspendLayout();
            this.SuspendLayout();
            // 
            // root
            // 
            this.root.ColumnCount = 1;
            this.root.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.root.Controls.Add(this.rtbText, 0, 0);
            this.root.Controls.Add(this.statsPanel, 0, 1);
            this.root.Dock = System.Windows.Forms.DockStyle.Fill;
            this.root.Location = new System.Drawing.Point(0, 0);
            this.root.Name = "root";
            this.root.RowCount = 2;
            this.root.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.root.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.root.Size = new System.Drawing.Size(544, 361);
            this.root.TabIndex = 0;
            // 
            // rtbText
            // 
            this.rtbText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbText.Location = new System.Drawing.Point(3, 3);
            this.rtbText.Name = "rtbText";
            this.rtbText.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.rtbText.Size = new System.Drawing.Size(538, 245);
            this.rtbText.TabIndex = 0;
            this.rtbText.Text = "";
            // 
            // statsPanel
            // 
            this.statsPanel.BackColor = System.Drawing.SystemColors.ControlDark;
            this.statsPanel.Controls.Add(this.statsGrid);
            this.statsPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statsPanel.Location = new System.Drawing.Point(3, 254);
            this.statsPanel.Name = "statsPanel";
            this.statsPanel.Padding = new System.Windows.Forms.Padding(10, 8, 10, 8);
            this.statsPanel.Size = new System.Drawing.Size(538, 104);
            this.statsPanel.TabIndex = 1;
            // 
            // statsGrid
            // 
            this.statsGrid.ColumnCount = 2;
            this.statsGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.statsGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
            this.statsGrid.Controls.Add(this.lblWords, 0, 0);
            this.statsGrid.Controls.Add(this.lblTop, 1, 0);
            this.statsGrid.Controls.Add(this.lblUnique, 0, 1);
            this.statsGrid.Controls.Add(this.lblReading, 1, 1);
            this.statsGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.statsGrid.Location = new System.Drawing.Point(10, 8);
            this.statsGrid.Name = "statsGrid";
            this.statsGrid.RowCount = 2;
            this.statsGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.statsGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.statsGrid.Size = new System.Drawing.Size(518, 88);
            this.statsGrid.TabIndex = 0;
            // 
            // lblWords
            // 
            this.lblWords.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblWords.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblWords.Location = new System.Drawing.Point(3, 0);
            this.lblWords.Name = "lblWords";
            this.lblWords.Padding = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWords.Size = new System.Drawing.Size(201, 44);
            this.lblWords.TabIndex = 0;
            this.lblWords.Text = "Слов: 0";
            this.lblWords.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTop
            // 
            this.lblTop.AutoSize = true;
            this.lblTop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblTop.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTop.Location = new System.Drawing.Point(210, 0);
            this.lblTop.Name = "lblTop";
            this.lblTop.Padding = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTop.Size = new System.Drawing.Size(305, 44);
            this.lblTop.TabIndex = 1;
            this.lblTop.Text = "Топ слов";
            this.lblTop.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblUnique
            // 
            this.lblUnique.AutoSize = true;
            this.lblUnique.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblUnique.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblUnique.Location = new System.Drawing.Point(3, 44);
            this.lblUnique.Name = "lblUnique";
            this.lblUnique.Padding = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUnique.Size = new System.Drawing.Size(201, 44);
            this.lblUnique.TabIndex = 2;
            this.lblUnique.Text = "Уникальных: 0";
            this.lblUnique.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblReading
            // 
            this.lblReading.AutoSize = true;
            this.lblReading.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblReading.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblReading.Location = new System.Drawing.Point(210, 44);
            this.lblReading.Name = "lblReading";
            this.lblReading.Padding = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblReading.Size = new System.Drawing.Size(305, 44);
            this.lblReading.TabIndex = 3;
            this.lblReading.Text = "Время чтнеия: 0 мин";
            this.lblReading.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // debounceTimer
            // 
            this.debounceTimer.Interval = 300;
            // 
            // AnalyzerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(544, 361);
            this.Controls.Add(this.root);
            this.MaximumSize = new System.Drawing.Size(560, 400);
            this.Name = "AnalyzerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Анализатор текста";
            this.root.ResumeLayout(false);
            this.statsPanel.ResumeLayout(false);
            this.statsGrid.ResumeLayout(false);
            this.statsGrid.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel root;
        private System.Windows.Forms.RichTextBox rtbText;
        private System.Windows.Forms.Panel statsPanel;
        private System.Windows.Forms.TableLayoutPanel statsGrid;
        private System.Windows.Forms.Label lblWords;
        private System.Windows.Forms.Label lblTop;
        private System.Windows.Forms.Label lblUnique;
        private System.Windows.Forms.Label lblReading;
        private System.Windows.Forms.Timer debounceTimer;
    }
}