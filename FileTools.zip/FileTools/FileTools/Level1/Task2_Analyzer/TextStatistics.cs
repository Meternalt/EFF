﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace FileTools.Level1.Task2_Analyzer
{
    public class TextStatistics
    {
        public int WordCount { get; private set; }
        public int UniqueWords { get; private set; }
        public double ReadingMinutes { get; private set; }
        public IList<KeyValuePair<string, int>> Top5 { get; private set; }

        public TextStatistics()
        {
            Top5 = new List<KeyValuePair<string, int>>();
        }

        // Считает статистику. Может вызываться из фонового потока.
        // Периодически проверяет токен — если пользователь начал печатать снова, отменяемся.
        public static TextStatistics Compute(string text, CancellationToken token)
        {
            var stats = new TextStatistics();

            if (string.IsNullOrEmpty(text))
            {
                stats.Top5 = new List<KeyValuePair<string, int>>();
                return stats;
            }

            // Разбиваем текст на слова.
            // Слово = максимальная последовательность букв.
            var words = new List<string>(capacity: Math.Max(16, text.Length / 6));
            var sb = new StringBuilder(64);

            foreach (char c in text)
            {
                token.ThrowIfCancellationRequested();

                if (char.IsLetter(c))
                {
                    sb.Append(char.ToLowerInvariant(c));
                }
                else if (sb.Length > 0)
                {
                    words.Add(sb.ToString());
                    sb.Clear();
                }
            }
            if (sb.Length > 0) words.Add(sb.ToString());

            stats.WordCount = words.Count;

            // Частотный словарь
            var freq = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (var w in words)
            {
                int n;
                if (freq.TryGetValue(w, out n)) freq[w] = n + 1;
                else freq[w] = 1;
            }

            stats.UniqueWords = freq.Count;

            // Топ-5
            stats.Top5 = freq
                .OrderByDescending(kv => kv.Value)
                .ThenBy(kv => kv.Key, StringComparer.Ordinal)
                .Take(5)
                .ToList();

            // Средняя скорость чтения — 200 слов/мин
            stats.ReadingMinutes = words.Count / 200.0;

            return stats;
        }
    }
}