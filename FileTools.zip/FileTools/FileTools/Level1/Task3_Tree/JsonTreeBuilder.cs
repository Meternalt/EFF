﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace FileTools.Level1.Task3_Tree
{
    internal static class TreeLimits
    {
        public const int LazyThreshold = 200;
    }

    internal class JsonNodePayload
    {
        public JsonElement Element { get; }
        public string DisplayName { get; }
        public bool Lazy { get; set; }

        public JsonNodePayload(JsonElement element, string displayName, bool lazy)
        {
            Element = element;
            DisplayName = displayName;
            Lazy = lazy;
        }
    }

    internal class FolderPayload
    {
        public string Path { get; }
        public bool Lazy { get; set; }

        public FolderPayload(string path, bool lazy)
        {
            Path = path;
            Lazy = lazy;
        }
    }

    internal static class JsonTreeBuilder
    {
        public static TreeNode BuildNode(string name, JsonElement element, int lazyDepth)
        {
            var node = new TreeNode(FormatLabel(name, element))
            {
                Tag = new JsonNodePayload(element, name, lazy: false)
            };

            switch (element.ValueKind)
            {
                case JsonValueKind.Object:
                case JsonValueKind.Array:
                    int count = CountChildren(element);
                    if (count == 0) return node;

                    if (lazyDepth > 0 || count <= TreeLimits.LazyThreshold)
                    {
                        var children = new TreeNode[count];
                        int i = 0;
                        foreach (var child in EnumerateChildren(element))
                        {
                            children[i++] = BuildNode(child.Item1, child.Item2,
                                Math.Max(0, lazyDepth - 1));
                        }
                        node.Nodes.AddRange(children);
                    }
                    else
                    {
                        node.Nodes.Add(new TreeNode("…"));
                        ((JsonNodePayload)node.Tag).Lazy = true;
                    }
                    break;
            }

            return node;
        }

        public static int CountChildren(JsonElement element)
        {
            if (element.ValueKind == JsonValueKind.Object)
                return element.EnumerateObject().Count();
            if (element.ValueKind == JsonValueKind.Array)
                return element.GetArrayLength();
            return 0;
        }

        public static IEnumerable<Tuple<string, JsonElement>> EnumerateChildren(JsonElement element)
        {
            if (element.ValueKind == JsonValueKind.Object)
            {
                foreach (var p in element.EnumerateObject())
                    yield return Tuple.Create(p.Name, p.Value);
            }
            else if (element.ValueKind == JsonValueKind.Array)
            {
                int i = 0;
                foreach (var v in element.EnumerateArray())
                    yield return Tuple.Create("[" + i++ + "]", v);
            }
        }

        public static string FormatLabel(string name, JsonElement element)
        {
            switch (element.ValueKind)
            {
                case JsonValueKind.Object:
                    return name + "  { }";
                case JsonValueKind.Array:
                    return name + "  [" + element.GetArrayLength() + "]";
                case JsonValueKind.String:
                    var s = element.GetString() ?? "";
                    if (s.Length > 40) s = s.Substring(0, 40) + "…";
                    return name + " = \"" + s + "\"";
                case JsonValueKind.Number:
                    return name + " = " + element.GetRawText();
                case JsonValueKind.True:
                    return name + " = true";
                case JsonValueKind.False:
                    return name + " = false";
                case JsonValueKind.Null:
                    return name + " = null";
                default:
                    return name;
            }
        }
    }
}