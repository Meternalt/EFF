﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Linq;
using System.Windows.Forms;

namespace FileTools.Level1.Task3_Tree
{
    public partial class TreeNavigatorForm : Form
    {
        private JsonDocument _currentDocument;

        public TreeNavigatorForm()
        {
            InitializeComponent();

            treeView1.BeforeExpand += TreeView1_BeforeExpand;
            treeView1.AfterSelect += TreeView1_AfterSelect;

            btnOpenJson.Click += (s, e) => OpenJson();
            btnOpenFolder.Click += (s, e) => OpenFolder();
        }

        // ---------------- JSON ----------------
        private void OpenJson()
        {
            if (openJsonDialog.ShowDialog(this) != DialogResult.OK) return;

            try
            {
                if (_currentDocument != null)
                {
                    _currentDocument.Dispose();
                    _currentDocument = null;
                }

                using (var stream = File.OpenRead(openJsonDialog.FileName))
                {
                    _currentDocument = JsonDocument.Parse(stream);
                }

                int lazyDepth = chkCollapse.Checked ? 0 : 2;

                var rootElement = _currentDocument.RootElement.Clone();
                var rootNode = JsonTreeBuilder.BuildNode("$", rootElement, lazyDepth);

                treeView1.BeginUpdate();
                try
                {
                    treeView1.Nodes.Clear();
                    treeView1.Nodes.Add(rootNode);
                }
                finally
                {
                    treeView1.EndUpdate();
                }

                rootNode.Expand();
                treeView1.SelectedNode = rootNode;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this,
                    "Не удалось открыть файл: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ---------------- Папка ----------------
        private void OpenFolder()
        {
            if (browseFolderDialog.ShowDialog(this) != DialogResult.OK) return;

            try
            {
                var rootPath = browseFolderDialog.SelectedPath;
                var rootNode = BuildFolderNode(rootPath);

                treeView1.BeginUpdate();
                try
                {
                    treeView1.Nodes.Clear();
                    treeView1.Nodes.Add(rootNode);
                }
                finally
                {
                    treeView1.EndUpdate();
                }

                rootNode.Expand();
                treeView1.SelectedNode = rootNode;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this,
                    "Не удалось открыть папку: " + ex.Message,
                    "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private TreeNode BuildFolderNode(string path)
        {
            var node = new TreeNode(Path.GetFileName(path) + "  /");
            node.Tag = new FolderPayload(path, lazy: false);

            string[] subdirs;
            try
            {
                subdirs = Directory.GetDirectories(path);
            }
            catch
            {
                subdirs = new string[0];
            }

            int lazyDepth = chkCollapse.Checked ? 0 : 2;
            AddFolderChildren(node, subdirs, lazyDepth);
            return node;
        }

        private void AddFolderChildren(TreeNode parent, string[] subdirs, int lazyDepth)
        {
            var children = new TreeNode[subdirs.Length];
            for (int i = 0; i < subdirs.Length; i++)
            {
                var sub = subdirs[i];
                var child = new TreeNode(Path.GetFileName(sub) + "  /");
                child.Tag = new FolderPayload(sub, lazy: false);

                if (lazyDepth > 0)
                {
                    string[] subs;
                    try { subs = Directory.GetDirectories(sub); }
                    catch { subs = new string[0]; }

                    if (subs.Length > 0)
                        AddFolderChildren(child, subs, lazyDepth - 1);
                }
                else
                {
                    if (HasSubdirectories(sub))
                    {
                        child.Nodes.Add(new TreeNode("…"));
                        ((FolderPayload)child.Tag).Lazy = true;
                    }
                }

                children[i] = child;
            }
            parent.Nodes.AddRange(children);
        }

        private static bool HasSubdirectories(string path)
        {
            try
            {
                using (var e = Directory.EnumerateDirectories(path).GetEnumerator())
                    return e.MoveNext();
            }
            catch
            {
                return false;
            }
        }

        // ---------------- Lazy loading ----------------
        private void TreeView1_BeforeExpand(object sender, TreeViewCancelEventArgs e)
        {
            var node = e.Node;
            if (node == null) return;

            var jsonPayload = node.Tag as JsonNodePayload;
            if (jsonPayload != null && jsonPayload.Lazy)
            {
                BuildJsonChildren(node, jsonPayload);
                return;
            }

            var folderPayload = node.Tag as FolderPayload;
            if (folderPayload != null && folderPayload.Lazy)
            {
                BuildFolderChildren(node, folderPayload);
            }
        }

        private void BuildJsonChildren(TreeNode node, JsonNodePayload payload)
        {
            var element = payload.Element;
            int count = JsonTreeBuilder.CountChildren(element);

            int lazyDepth = chkCollapse.Checked ? 0 : 1;

            treeView1.BeginUpdate();
            try
            {
                node.Nodes.Clear();
                var children = new TreeNode[count];
                int i = 0;
                foreach (var child in JsonTreeBuilder.EnumerateChildren(element))
                {
                    children[i++] = JsonTreeBuilder.BuildNode(child.Item1, child.Item2, lazyDepth);
                }
                node.Nodes.AddRange(children);
            }
            finally
            {
                treeView1.EndUpdate();
            }

            payload.Lazy = false;
        }

        private void BuildFolderChildren(TreeNode node, FolderPayload payload)
        {
            string[] subdirs;
            try { subdirs = Directory.GetDirectories(payload.Path); }
            catch { subdirs = new string[0]; }

            treeView1.BeginUpdate();
            try
            {
                node.Nodes.Clear();
                AddFolderChildren(node, subdirs, lazyDepth: 0);
            }
            finally
            {
                treeView1.EndUpdate();
            }

            payload.Lazy = false;
        }

        // ---------------- Информация об узле ----------------
        private void TreeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            var node = e.Node;
            if (node == null) return;

            lblNodePath.Text = BuildPath(node);

            var jp = node.Tag as JsonNodePayload;
            if (jp != null)
            {
                lblNodeName.Text = jp.DisplayName;
                lblNodeType.Text = jp.Element.ValueKind.ToString();
                lblNodeValue.Text = DescribeValue(jp.Element);
                return;
            }

            var fp = node.Tag as FolderPayload;
            if (fp != null)
            {
                lblNodeName.Text = Path.GetFileName(fp.Path);
                lblNodeType.Text = "Folder";
                lblNodeValue.Text = fp.Path;
                return;
            }

            lblNodeName.Text = "—";
            lblNodeType.Text = "—";
            lblNodeValue.Text = "—";
        }

        private static string BuildPath(TreeNode node)
        {
            var parts = new List<string>();
            var cur = node;
            while (cur != null)
            {
                parts.Insert(0, cur.Text);
                cur = cur.Parent;
            }
            return string.Join(" / ", parts.ToArray());
        }

        private static string DescribeValue(JsonElement el)
        {
            switch (el.ValueKind)
            {
                case JsonValueKind.String: return el.GetString() ?? "";
                case JsonValueKind.Number: return el.GetRawText();
                case JsonValueKind.True: return "true";
                case JsonValueKind.False: return "false";
                case JsonValueKind.Null: return "null";
                case JsonValueKind.Object: return "{" + el.EnumerateObject().Count() + " свойств}";
                case JsonValueKind.Array: return "[" + el.GetArrayLength() + " элементов]";
                default: return el.ValueKind.ToString();
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (_currentDocument != null)
            {
                _currentDocument.Dispose();
                _currentDocument = null;
            }
            base.OnFormClosing(e);
        }
    }
}