﻿namespace FileTools.Level1.Task3_Tree
{
    partial class TreeNavigatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.root = new System.Windows.Forms.TableLayoutPanel();
            this.topPanel = new System.Windows.Forms.Panel();
            this.toolbarFlow = new System.Windows.Forms.FlowLayoutPanel();
            this.btnOpenJson = new System.Windows.Forms.Button();
            this.btnOpenFolder = new System.Windows.Forms.Button();
            this.chkCollapse = new System.Windows.Forms.CheckBox();
            this.body = new System.Windows.Forms.TableLayoutPanel();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.infoPanel = new System.Windows.Forms.Panel();
            this.infoGrid = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblNodeName = new System.Windows.Forms.Label();
            this.lblNodeType = new System.Windows.Forms.Label();
            this.lblNodeValue = new System.Windows.Forms.Label();
            this.lblNodePath = new System.Windows.Forms.Label();
            this.openJsonDialog = new System.Windows.Forms.OpenFileDialog();
            this.browseFolderDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.root.SuspendLayout();
            this.topPanel.SuspendLayout();
            this.toolbarFlow.SuspendLayout();
            this.body.SuspendLayout();
            this.infoPanel.SuspendLayout();
            this.infoGrid.SuspendLayout();
            this.SuspendLayout();
            // 
            // root
            // 
            this.root.ColumnCount = 1;
            this.root.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.root.Controls.Add(this.topPanel, 0, 0);
            this.root.Controls.Add(this.body, 0, 1);
            this.root.Dock = System.Windows.Forms.DockStyle.Fill;
            this.root.Location = new System.Drawing.Point(0, 0);
            this.root.Name = "root";
            this.root.RowCount = 2;
            this.root.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 48F));
            this.root.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.root.Size = new System.Drawing.Size(884, 561);
            this.root.TabIndex = 0;
            // 
            // topPanel
            // 
            this.topPanel.BackColor = System.Drawing.Color.Gainsboro;
            this.topPanel.Controls.Add(this.toolbarFlow);
            this.topPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.topPanel.Location = new System.Drawing.Point(3, 3);
            this.topPanel.Name = "topPanel";
            this.topPanel.Padding = new System.Windows.Forms.Padding(8);
            this.topPanel.Size = new System.Drawing.Size(878, 42);
            this.topPanel.TabIndex = 0;
            // 
            // toolbarFlow
            // 
            this.toolbarFlow.Controls.Add(this.btnOpenJson);
            this.toolbarFlow.Controls.Add(this.btnOpenFolder);
            this.toolbarFlow.Controls.Add(this.chkCollapse);
            this.toolbarFlow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.toolbarFlow.Location = new System.Drawing.Point(8, 8);
            this.toolbarFlow.Name = "toolbarFlow";
            this.toolbarFlow.Size = new System.Drawing.Size(862, 26);
            this.toolbarFlow.TabIndex = 0;
            this.toolbarFlow.WrapContents = false;
            // 
            // btnOpenJson
            // 
            this.btnOpenJson.AutoSize = true;
            this.btnOpenJson.Location = new System.Drawing.Point(3, 3);
            this.btnOpenJson.Name = "btnOpenJson";
            this.btnOpenJson.Padding = new System.Windows.Forms.Padding(8, 4, 8, 4);
            this.btnOpenJson.Size = new System.Drawing.Size(108, 31);
            this.btnOpenJson.TabIndex = 0;
            this.btnOpenJson.Text = "Открыть JSON";
            this.btnOpenJson.UseVisualStyleBackColor = true;
            // 
            // btnOpenFolder
            // 
            this.btnOpenFolder.AutoSize = true;
            this.btnOpenFolder.Location = new System.Drawing.Point(117, 3);
            this.btnOpenFolder.Name = "btnOpenFolder";
            this.btnOpenFolder.Padding = new System.Windows.Forms.Padding(8, 4, 8, 4);
            this.btnOpenFolder.Size = new System.Drawing.Size(109, 31);
            this.btnOpenFolder.TabIndex = 1;
            this.btnOpenFolder.Text = "Открыть папку";
            this.btnOpenFolder.UseVisualStyleBackColor = true;
            // 
            // chkCollapse
            // 
            this.chkCollapse.AutoSize = true;
            this.chkCollapse.Location = new System.Drawing.Point(249, 8);
            this.chkCollapse.Margin = new System.Windows.Forms.Padding(20, 8, 0, 0);
            this.chkCollapse.Name = "chkCollapse";
            this.chkCollapse.Size = new System.Drawing.Size(73, 17);
            this.chkCollapse.TabIndex = 2;
            this.chkCollapse.Text = "Свернуто";
            this.chkCollapse.UseVisualStyleBackColor = true;
            // 
            // body
            // 
            this.body.ColumnCount = 2;
            this.body.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70F));
            this.body.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.body.Controls.Add(this.treeView1, 0, 0);
            this.body.Controls.Add(this.infoPanel, 1, 0);
            this.body.Dock = System.Windows.Forms.DockStyle.Fill;
            this.body.Location = new System.Drawing.Point(3, 51);
            this.body.Name = "body";
            this.body.RowCount = 1;
            this.body.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.body.Size = new System.Drawing.Size(878, 507);
            this.body.TabIndex = 1;
            // 
            // treeView1
            // 
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.treeView1.FullRowSelect = true;
            this.treeView1.HideSelection = false;
            this.treeView1.ItemHeight = 22;
            this.treeView1.Location = new System.Drawing.Point(3, 3);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(608, 501);
            this.treeView1.TabIndex = 0;
            // 
            // infoPanel
            // 
            this.infoPanel.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.infoPanel.Controls.Add(this.infoGrid);
            this.infoPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.infoPanel.Location = new System.Drawing.Point(617, 3);
            this.infoPanel.Name = "infoPanel";
            this.infoPanel.Padding = new System.Windows.Forms.Padding(10);
            this.infoPanel.Size = new System.Drawing.Size(258, 501);
            this.infoPanel.TabIndex = 1;
            // 
            // infoGrid
            // 
            this.infoGrid.ColumnCount = 2;
            this.infoGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 90F));
            this.infoGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.infoGrid.Controls.Add(this.label1, 0, 0);
            this.infoGrid.Controls.Add(this.label2, 0, 1);
            this.infoGrid.Controls.Add(this.label3, 0, 2);
            this.infoGrid.Controls.Add(this.label4, 0, 3);
            this.infoGrid.Controls.Add(this.lblNodeName, 1, 0);
            this.infoGrid.Controls.Add(this.lblNodeType, 1, 1);
            this.infoGrid.Controls.Add(this.lblNodeValue, 1, 2);
            this.infoGrid.Controls.Add(this.lblNodePath, 1, 3);
            this.infoGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.infoGrid.Location = new System.Drawing.Point(10, 10);
            this.infoGrid.Name = "infoGrid";
            this.infoGrid.RowCount = 4;
            this.infoGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.infoGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.infoGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.infoGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.infoGrid.Size = new System.Drawing.Size(238, 481);
            this.infoGrid.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Узел:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(3, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "Тип:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(3, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 28);
            this.label3.TabIndex = 2;
            this.label3.Text = "Значение:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(3, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 397);
            this.label4.TabIndex = 3;
            this.label4.Text = "Путь:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNodeName
            // 
            this.lblNodeName.AutoEllipsis = true;
            this.lblNodeName.AutoSize = true;
            this.lblNodeName.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNodeName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblNodeName.Location = new System.Drawing.Point(93, 0);
            this.lblNodeName.Name = "lblNodeName";
            this.lblNodeName.Size = new System.Drawing.Size(142, 28);
            this.lblNodeName.TabIndex = 4;
            this.lblNodeName.Text = "-";
            this.lblNodeName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNodeType
            // 
            this.lblNodeType.AutoSize = true;
            this.lblNodeType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNodeType.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblNodeType.Location = new System.Drawing.Point(93, 28);
            this.lblNodeType.Name = "lblNodeType";
            this.lblNodeType.Size = new System.Drawing.Size(142, 28);
            this.lblNodeType.TabIndex = 5;
            this.lblNodeType.Text = "-";
            this.lblNodeType.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNodeValue
            // 
            this.lblNodeValue.AutoSize = true;
            this.lblNodeValue.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblNodeValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblNodeValue.Location = new System.Drawing.Point(93, 56);
            this.lblNodeValue.Name = "lblNodeValue";
            this.lblNodeValue.Size = new System.Drawing.Size(142, 28);
            this.lblNodeValue.TabIndex = 6;
            this.lblNodeValue.Text = "-";
            this.lblNodeValue.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblNodePath
            // 
            this.lblNodePath.AutoSize = true;
            this.lblNodePath.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblNodePath.Location = new System.Drawing.Point(93, 84);
            this.lblNodePath.Name = "lblNodePath";
            this.lblNodePath.Size = new System.Drawing.Size(11, 15);
            this.lblNodePath.TabIndex = 7;
            this.lblNodePath.Text = "-";
            this.lblNodePath.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // openJsonDialog
            // 
            this.openJsonDialog.FileName = "openFileDialog1";
            this.openJsonDialog.Filter = "\"JSON файлы (*.json)|*.json|Все файлы (*.*)|*.*\"";
            // 
            // TreeNavigatorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 561);
            this.Controls.Add(this.root);
            this.MinimumSize = new System.Drawing.Size(640, 400);
            this.Name = "TreeNavigatorForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Дерево JSON";
            this.root.ResumeLayout(false);
            this.topPanel.ResumeLayout(false);
            this.toolbarFlow.ResumeLayout(false);
            this.toolbarFlow.PerformLayout();
            this.body.ResumeLayout(false);
            this.infoPanel.ResumeLayout(false);
            this.infoGrid.ResumeLayout(false);
            this.infoGrid.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel root;
        private System.Windows.Forms.Panel topPanel;
        private System.Windows.Forms.FlowLayoutPanel toolbarFlow;
        private System.Windows.Forms.Button btnOpenJson;
        private System.Windows.Forms.Button btnOpenFolder;
        private System.Windows.Forms.CheckBox chkCollapse;
        private System.Windows.Forms.TableLayoutPanel body;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.Panel infoPanel;
        private System.Windows.Forms.TableLayoutPanel infoGrid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblNodeName;
        private System.Windows.Forms.Label lblNodeType;
        private System.Windows.Forms.Label lblNodeValue;
        private System.Windows.Forms.Label lblNodePath;
        private System.Windows.Forms.OpenFileDialog openJsonDialog;
        private System.Windows.Forms.FolderBrowserDialog browseFolderDialog;
    }
}