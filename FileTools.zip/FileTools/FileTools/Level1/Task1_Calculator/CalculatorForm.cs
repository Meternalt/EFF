﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace FileTools.Level1.Task1_Calculator
{
    public partial class CalculatorForm : Form
    {
        private readonly OrderModel _order = new OrderModel();
        private readonly OrderValidator _validator = new OrderValidator();

        public CalculatorForm()
        {
            InitializeComponent();

            // Подключаем модель к реальным контролам
            _order.ServicesHost = servicesPanel;
            _order.ContactBox = txtContact;

            BuildServices();
            WireEvents();
            Recalc();
        }

        // ---- Динамически создаём строки услуг ----
        private void BuildServices()
        {
            var defs = new (string Name, decimal Price)[]
            {
                ("Разработка", 1500m),
                ("Дизайн", 1200m),
                ("Тестирование", 900m)
            };

            foreach (var def in defs)
            {
                var row = new FlowLayoutPanel
                {
                    AutoSize = true,
                    AutoSizeMode = AutoSizeMode.GrowAndShrink,
                    FlowDirection = FlowDirection.LeftToRight,
                    WrapContents = false,
                    Margin = new Padding(0, 4, 0, 4)
                };

                var cb = new CheckBox
                {
                    Text = def.Name,
                    AutoSize = true,
                    MinimumSize = new Size(160, 24)
                };

                var num = new NumericUpDown
                {
                    Minimum = 1,
                    Maximum = 500,
                    Value = 1,
                    Width = 60,
                    Enabled = false
                };

                var unitLabel = new Label
                {
                    Text = "ч.",
                    AutoSize = true,
                    Padding = new Padding(4, 6, 0, 0)
                };

                var option = new ServiceOption
                {
                    Name = def.Name,
                    PricePerHour = def.Price,
                    Hours = 1,
                    CheckBoxRef = cb,
                    HoursRef = num
                };
                _order.Services.Add(option);

                cb.CheckedChanged += (s, e) =>
                {
                    num.Enabled = cb.Checked;
                    option.Selected = cb.Checked;
                    Recalc();
                };
                num.ValueChanged += (s, e) =>
                {
                    option.Hours = (int)num.Value;
                    Recalc();
                };

                row.Controls.Add(cb);
                row.Controls.Add(num);
                row.Controls.Add(unitLabel);
                servicesPanel.Controls.Add(row);
            }
        }

        // ---- Привязка статических контролов ----
        private void WireEvents()
        {
            cbClientType.SelectedIndexChanged += (s, e) =>
            {
                switch (cbClientType.SelectedIndex)
                {
                    case 1: _order.ClientMultiplier = 1.15m; break; // Постоянный
                    case 2: _order.ClientMultiplier = 1.30m; break; // VIP
                    default: _order.ClientMultiplier = 1.00m; break;
                }
                Recalc();
            };


            txtContact.TextChanged += (s, e) =>
            {
                _order.Contact = txtContact.Text;
                // Мягкая валидация: как только поле стало валидным — снимаем подсветку
                if (!string.IsNullOrWhiteSpace(_order.Contact))
                    errors.SetError(txtContact, string.Empty);
            };

            btnOrder.Click += (s, e) => OnOrderClick();
        }

   

        private void Recalc()
        {
            lblTotal.Text = "Итого: " + _order.Total.ToString("N0") + " ₽";
        }

        private void OnOrderClick()
        {
            errors.Clear(); // снять все подсветки

            var issues = _validator.Validate(_order);

            if (issues.Count == 0)
            {
                MessageBox.Show(this,
                    "Заказ оформлен.\nИтого: " + _order.Total.ToString("N0") + " ₽",
                    "Успех",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            // Никаких MessageBox на каждую ошибку — только ErrorProvider
            foreach (var err in issues)
                errors.SetError(err.Control, err.Message);

            issues[0].Control.Focus();
        }
    }
}