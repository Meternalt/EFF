﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace FileTools.Level1.Task1_Calculator
{
    public class ServiceOption
    {
        public string Name {get; set;}
        public decimal PricePerHour {get; set;}
        public bool Selected {get; set;}
        public int Hours {get; set;}
        public CheckBox CheckBoxRef {get; set;}
        public NumericUpDown HoursRef {get; set;}
    }

    public class OrderModel
    {
        public List<ServiceOption> Services {get;} = new List<ServiceOption>();

        public decimal ClientMultiplier {get; set;} = 1.0m;
        public decimal UrgencyMultiplier {get; set;} = 1.0m;

        public string Contact {get; set;} = string.Empty;

        public Control ServicesHost {get; set;}
        public Control ContactBox {get; set;}

        public decimal Total
        {
            get
            {
                decimal baseSum = 0m;
                foreach (var s in Services)
                {
                    if (s.Selected)
                        baseSum += s.Hours * s.PricePerHour;
                }
                return baseSum * ClientMultiplier * UrgencyMultiplier;
            }
        }
    }
}