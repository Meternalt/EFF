﻿using System.Collections.Generic;
using System.Windows.Forms;

namespace FileTools.Level1.Task1_Calculator
{
    public class ValidationError
    {
        public Control Control { get; }
        public string Message { get; }

        public ValidationError(Control control, string message)
        {
            Control = control;
            Message = message;
        }
    }

    public class OrderValidator
    {
        public IList<ValidationError> Validate(OrderModel order)
        {
            var errors = new List<ValidationError>();

            // 1) Хотя бы одна услуга выбрана
            bool anySelected = false;
            foreach (var s in order.Services)
            {
                if (s.Selected) { anySelected = true; break; }
            }
            if (!anySelected)
                errors.Add(new ValidationError(order.ServicesHost,
                    "Выберите хотя бы одну услугу"));

            // 2) Контакт заполнен
            if (string.IsNullOrWhiteSpace(order.Contact))
                errors.Add(new ValidationError(order.ContactBox,
                    "Укажите email или телефон для связи"));
            else if (order.Contact.Length > 100)
                errors.Add(new ValidationError(order.ContactBox,
                    "Контакт слишком длинный (максимум 100 символов)"));

            return errors;
        }
    }
}