﻿namespace FileTools.Level1.Task1_Calculator
{
    partial class CalculatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.root = new System.Windows.Forms.TableLayoutPanel();
            this.gbServices = new System.Windows.Forms.GroupBox();
            this.servicesPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.gbParams = new System.Windows.Forms.GroupBox();
            this.paramsGrid = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlUrgency = new System.Windows.Forms.Panel();
            this.urgencyFlow = new System.Windows.Forms.FlowLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.footer = new System.Windows.Forms.Panel();
            this.btnOrder = new System.Windows.Forms.Button();
            this.lblTotal = new System.Windows.Forms.Label();
            this.errors = new System.Windows.Forms.ErrorProvider(this.components);
            this.rbExpress = new System.Windows.Forms.RadioButton();
            this.rbUrgent = new System.Windows.Forms.RadioButton();
            this.rbNormal = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.cbClientType = new System.Windows.Forms.ComboBox();
            this.root.SuspendLayout();
            this.gbServices.SuspendLayout();
            this.gbParams.SuspendLayout();
            this.paramsGrid.SuspendLayout();
            this.pnlUrgency.SuspendLayout();
            this.urgencyFlow.SuspendLayout();
            this.footer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errors)).BeginInit();
            this.SuspendLayout();
            // 
            // root
            // 
            this.root.ColumnCount = 2;
            this.root.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.root.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.root.Controls.Add(this.gbServices, 0, 0);
            this.root.Controls.Add(this.gbParams, 1, 0);
            this.root.Controls.Add(this.footer, 0, 1);
            this.root.Dock = System.Windows.Forms.DockStyle.Fill;
            this.root.Location = new System.Drawing.Point(0, 0);
            this.root.Name = "root";
            this.root.RowCount = 2;
            this.root.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.root.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.root.Size = new System.Drawing.Size(804, 521);
            this.root.TabIndex = 0;
            // 
            // gbServices
            // 
            this.gbServices.Controls.Add(this.servicesPanel);
            this.gbServices.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbServices.Location = new System.Drawing.Point(3, 3);
            this.gbServices.Name = "gbServices";
            this.gbServices.Size = new System.Drawing.Size(396, 445);
            this.gbServices.TabIndex = 0;
            this.gbServices.TabStop = false;
            this.gbServices.Text = "Услуги";
            // 
            // servicesPanel
            // 
            this.servicesPanel.AutoScroll = true;
            this.servicesPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.servicesPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.servicesPanel.Location = new System.Drawing.Point(3, 16);
            this.servicesPanel.Name = "servicesPanel";
            this.servicesPanel.Padding = new System.Windows.Forms.Padding(8);
            this.servicesPanel.Size = new System.Drawing.Size(390, 426);
            this.servicesPanel.TabIndex = 0;
            this.servicesPanel.WrapContents = false;
            // 
            // gbParams
            // 
            this.gbParams.Controls.Add(this.paramsGrid);
            this.gbParams.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gbParams.Location = new System.Drawing.Point(405, 3);
            this.gbParams.Name = "gbParams";
            this.gbParams.Size = new System.Drawing.Size(396, 445);
            this.gbParams.TabIndex = 1;
            this.gbParams.TabStop = false;
            this.gbParams.Text = "Параметры";
            // 
            // paramsGrid
            // 
            this.paramsGrid.ColumnCount = 2;
            this.paramsGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.paramsGrid.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.paramsGrid.Controls.Add(this.label1, 0, 0);
            this.paramsGrid.Controls.Add(this.pnlUrgency, 1, 0);
            this.paramsGrid.Controls.Add(this.label2, 0, 1);
            this.paramsGrid.Controls.Add(this.txtContact, 1, 1);
            this.paramsGrid.Controls.Add(this.label3, 0, 2);
            this.paramsGrid.Controls.Add(this.cbClientType, 1, 2);
            this.paramsGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.paramsGrid.Location = new System.Drawing.Point(3, 16);
            this.paramsGrid.Name = "paramsGrid";
            this.paramsGrid.RowCount = 4;
            this.paramsGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.paramsGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.paramsGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.paramsGrid.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.paramsGrid.Size = new System.Drawing.Size(390, 426);
            this.paramsGrid.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Срочность";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnlUrgency
            // 
            this.pnlUrgency.Controls.Add(this.urgencyFlow);
            this.pnlUrgency.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlUrgency.Location = new System.Drawing.Point(133, 3);
            this.pnlUrgency.Name = "pnlUrgency";
            this.pnlUrgency.Size = new System.Drawing.Size(254, 26);
            this.pnlUrgency.TabIndex = 1;
            // 
            // urgencyFlow
            // 
            this.urgencyFlow.Controls.Add(this.rbNormal);
            this.urgencyFlow.Controls.Add(this.rbUrgent);
            this.urgencyFlow.Controls.Add(this.rbExpress);
            this.urgencyFlow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.urgencyFlow.Location = new System.Drawing.Point(0, 0);
            this.urgencyFlow.Name = "urgencyFlow";
            this.urgencyFlow.Size = new System.Drawing.Size(254, 26);
            this.urgencyFlow.TabIndex = 0;
            this.urgencyFlow.WrapContents = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label2.Location = new System.Drawing.Point(3, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 32);
            this.label2.TabIndex = 2;
            this.label2.Text = "Контакт";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtContact
            // 
            this.txtContact.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtContact.Location = new System.Drawing.Point(133, 35);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(254, 20);
            this.txtContact.TabIndex = 3;
            // 
            // footer
            // 
            this.footer.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.root.SetColumnSpan(this.footer, 2);
            this.footer.Controls.Add(this.btnOrder);
            this.footer.Controls.Add(this.lblTotal);
            this.footer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.footer.Location = new System.Drawing.Point(3, 454);
            this.footer.Name = "footer";
            this.footer.Padding = new System.Windows.Forms.Padding(10);
            this.footer.Size = new System.Drawing.Size(798, 64);
            this.footer.TabIndex = 4;
            // 
            // btnOrder
            // 
            this.btnOrder.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnOrder.Location = new System.Drawing.Point(618, 10);
            this.btnOrder.Name = "btnOrder";
            this.btnOrder.Size = new System.Drawing.Size(170, 44);
            this.btnOrder.TabIndex = 1;
            this.btnOrder.Text = "Оформить заказ";
            this.btnOrder.UseVisualStyleBackColor = true;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Dock = System.Windows.Forms.DockStyle.Left;
            this.lblTotal.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTotal.Location = new System.Drawing.Point(10, 10);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Padding = new System.Windows.Forms.Padding(0, 8, 0, 0);
            this.lblTotal.Size = new System.Drawing.Size(69, 29);
            this.lblTotal.TabIndex = 0;
            this.lblTotal.Text = "Итого: 0";
            this.lblTotal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // errors
            // 
            this.errors.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errors.ContainerControl = this;
            // 
            // rbExpress
            // 
            this.rbExpress.AutoSize = true;
            this.rbExpress.Location = new System.Drawing.Point(152, 3);
            this.rbExpress.Name = "rbExpress";
            this.rbExpress.Size = new System.Drawing.Size(74, 17);
            this.rbExpress.TabIndex = 2;
            this.rbExpress.TabStop = true;
            this.rbExpress.Text = "Экспресс";
            this.rbExpress.UseVisualStyleBackColor = true;
            // 
            // rbUrgent
            // 
            this.rbUrgent.AutoSize = true;
            this.rbUrgent.Location = new System.Drawing.Point(79, 3);
            this.rbUrgent.Name = "rbUrgent";
            this.rbUrgent.Size = new System.Drawing.Size(67, 17);
            this.rbUrgent.TabIndex = 1;
            this.rbUrgent.TabStop = true;
            this.rbUrgent.Text = "Срочная";
            this.rbUrgent.UseVisualStyleBackColor = true;
            // 
            // rbNormal
            // 
            this.rbNormal.AutoSize = true;
            this.rbNormal.Checked = true;
            this.rbNormal.Location = new System.Drawing.Point(3, 3);
            this.rbNormal.Name = "rbNormal";
            this.rbNormal.Size = new System.Drawing.Size(70, 17);
            this.rbNormal.TabIndex = 0;
            this.rbNormal.TabStop = true;
            this.rbNormal.Text = "Обычная";
            this.rbNormal.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Location = new System.Drawing.Point(3, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 32);
            this.label3.TabIndex = 4;
            this.label3.Text = "Тип клинта";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbClientType
            // 
            this.cbClientType.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cbClientType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbClientType.FormattingEnabled = true;
            this.cbClientType.Items.AddRange(new object[] {
            "Новый",
            "Постоянный",
            "ВИП"});
            this.cbClientType.Location = new System.Drawing.Point(133, 67);
            this.cbClientType.Name = "cbClientType";
            this.cbClientType.Size = new System.Drawing.Size(254, 21);
            this.cbClientType.TabIndex = 5;
            // 
            // CalculatorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(804, 521);
            this.Controls.Add(this.root);
            this.MinimumSize = new System.Drawing.Size(640, 460);
            this.Name = "CalculatorForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Анкета Калькулятор";
            this.root.ResumeLayout(false);
            this.gbServices.ResumeLayout(false);
            this.gbParams.ResumeLayout(false);
            this.paramsGrid.ResumeLayout(false);
            this.paramsGrid.PerformLayout();
            this.pnlUrgency.ResumeLayout(false);
            this.urgencyFlow.ResumeLayout(false);
            this.urgencyFlow.PerformLayout();
            this.footer.ResumeLayout(false);
            this.footer.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errors)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel root;
        private System.Windows.Forms.GroupBox gbServices;
        private System.Windows.Forms.FlowLayoutPanel servicesPanel;
        private System.Windows.Forms.GroupBox gbParams;
        private System.Windows.Forms.TableLayoutPanel paramsGrid;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlUrgency;
        private System.Windows.Forms.FlowLayoutPanel urgencyFlow;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.Panel footer;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnOrder;
        private System.Windows.Forms.ErrorProvider errors;
        private System.Windows.Forms.RadioButton rbNormal;
        private System.Windows.Forms.RadioButton rbUrgent;
        private System.Windows.Forms.RadioButton rbExpress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cbClientType;
    }
}